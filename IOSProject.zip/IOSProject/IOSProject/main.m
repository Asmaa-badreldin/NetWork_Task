//
//  main.m
//  IOSProject
//
//  Created by JETS on 4/9/16.
//  Copyright (c) 2016 ITI. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "iosAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([iosAppDelegate class]));
    }
}
