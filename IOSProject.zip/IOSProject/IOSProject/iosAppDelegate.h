//
//  iosAppDelegate.h
//  IOSProject
//
//  Created by JETS on 4/9/16.
//  Copyright (c) 2016 ITI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iosAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
