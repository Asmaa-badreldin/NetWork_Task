//
//  JETSProfile.m
//  ProjectBeans
//
//  Created by JETS on 4/3/16.
//  Copyright (c) 2016 JETS. All rights reserved.
//

#import "JETSProfile.h"

@implementation JETSProfile

@end
